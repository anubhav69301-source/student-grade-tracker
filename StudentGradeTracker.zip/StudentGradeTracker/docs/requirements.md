# Student Grade Tracker — Requirements

## Problem Statement
Teachers and small tutoring centers often track student performance using scattered
spreadsheets or paper records, making it hard to quickly compute averages, assign
letter grades consistently, or spot which subjects a student is struggling in. This
project provides a lightweight desktop application to record, validate, and analyze
student grades across a fixed subject set (Mathematics, English, Science), with
persistent storage and basic reporting.

## Objectives
- Allow a teacher to manage a roster of students
- Record and validate grades per subject for each student
- Automatically compute averages and letter grades
- Provide class-level analytics (top performer, subject averages, at-risk students)
- Persist data between sessions via file storage

## Target Users
Teachers or tutors managing a small class (roughly 5–100 students) who want a
simple, no-database desktop tool.

## Functional Requirements (3 modules)

### Module 1 — Student Management
- Add a new student (name, auto-generated ID)
- Prevent duplicate names
- Remove a student
- List all students

### Module 2 — Grade / Assessment Management
- Set/update a grade for a student in a specific subject (Mathematics, English, Science)
- Validate grade range (0–100)
- Reject grades for nonexistent students or subjects, with clear errors
- Compute per-student average and letter grade (A/B/C/D/F)

### Module 3 — Reporting & Analytics
- Generate a full class report (all students, averages, letter grades)
- Compute class-wide average per subject
- Identify the top-performing student
- Identify at-risk students (average below a configurable threshold, default 60)
- Export report data to CSV; import previously saved data on startup

## Non-Functional Requirements
1. **Usability** — GUI must allow adding a student and recording a grade in
   3 clicks or fewer from the main screen; invalid input shows an inline message,
   never a crash.
2. **Reliability** — malformed rows in the save file must be skipped with a
   logged warning rather than crashing the load process.
3. **Maintainability** — each module is implemented as independent classes with
   a single responsibility (validation, storage, reporting kept separate from
   the UI) so one module can change without touching the others.
4. **Performance** — all operations (add, grade, report) complete in under
   100ms for class sizes up to 500 students (in-memory `Map` operations, no
   unnecessary re-computation).
5. **Data validation / Security** — all user input (names, grades) is validated
   before being stored; grades outside 0–100 are rejected at the model layer,
   not just the UI layer, so invalid state can never be reached.
6. **Resource efficiency** — file I/O uses buffered readers/writers and closes
   resources via try-with-resources.
