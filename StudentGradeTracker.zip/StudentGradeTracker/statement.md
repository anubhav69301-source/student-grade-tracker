# Problem Statement

Teachers and small tutoring centers often track student performance using
scattered spreadsheets, making it hard to quickly compute averages, assign
consistent letter grades, or spot which students are struggling. This project
is a lightweight desktop application that records, validates, and analyzes
student grades across a fixed subject set (Mathematics, English, Science).

## Scope
- Single-class-at-a-time desktop tool (not multi-classroom / multi-user)
- Fixed subject set: Mathematics, English, Science
- Local file (CSV) persistence — no external database
- Swing-based GUI, no web/network component

## Target Users
Individual teachers or tutors managing a class of roughly 5–100 students who
want a simple, no-setup desktop tool rather than a spreadsheet or full SIS.

## High-Level Features
- Add / remove students (Student Management module)
- Record and validate per-subject grades, with automatic average and letter
  grade calculation (Grade/Assessment module)
- Class-wide analytics: subject averages, top performer, at-risk students
  (Reporting & Analytics module)
- Persistent storage to CSV, loaded automatically on startup
