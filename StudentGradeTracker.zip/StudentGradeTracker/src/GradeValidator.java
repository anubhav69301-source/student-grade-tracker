/**
 * Centralizes validation rules so they are enforced consistently
 * regardless of which module (UI, storage, reporting) calls in.
 */
public class GradeValidator {

    private static final double MIN_GRADE = 0.0;
    private static final double MAX_GRADE = 100.0;

    public static void validateGrade(double grade) throws InvalidGradeException {
        if (grade < MIN_GRADE || grade > MAX_GRADE) {
            throw new InvalidGradeException(
                "Grade must be between " + MIN_GRADE + " and " + MAX_GRADE + ". Got: " + grade
            );
        }
    }

    public static void validateName(String name) throws IllegalArgumentException {
        if (name == null || name.trim().isEmpty()) {
            throw new IllegalArgumentException("Student name cannot be empty.");
        }
    }
}
