/**
 * Thrown when a grade value fails validation (e.g., outside 0–100).
 */
public class InvalidGradeException extends Exception {
    public InvalidGradeException(String message) {
        super(message);
    }
}
