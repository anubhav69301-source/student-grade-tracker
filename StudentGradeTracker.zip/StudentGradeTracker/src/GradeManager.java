/**
 * MODULE 2: Grade / Assessment Management
 * Responsible for recording grades against existing students, with full
 * validation. Delegates roster lookups to StudentManager and value checks
 * to GradeValidator — this class just orchestrates the two and throws
 * meaningful checked exceptions when something is wrong.
 */
public class GradeManager {

    private final StudentManager studentManager;

    public GradeManager(StudentManager studentManager) {
        this.studentManager = studentManager;
    }

    /**
     * Sets a student's grade for a subject.
     * @throws StudentNotFoundException if the student doesn't exist
     * @throws InvalidGradeException if the grade is outside 0-100
     */
    public void setGrade(String studentName, Subject subject, double grade)
            throws StudentNotFoundException, InvalidGradeException {
        GradeValidator.validateGrade(grade);
        Student student = studentManager.getStudent(studentName); // throws if missing
        student.setGrade(subject, grade);
    }

    public double getGrade(String studentName, Subject subject) throws StudentNotFoundException {
        return studentManager.getStudent(studentName).getGrade(subject);
    }
}
