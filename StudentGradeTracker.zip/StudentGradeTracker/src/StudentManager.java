import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * MODULE 1: Student Management
 * Owns the roster of students — add, remove, look up, list.
 * Knows nothing about grades beyond delegating storage to Student objects,
 * and nothing about reporting or file I/O (those live in their own modules).
 */
public class StudentManager {

    private final Map<String, Student> studentsByName = new LinkedHashMap<>();
    private final AtomicInteger nextId = new AtomicInteger(1);

    /** Adds a student. Returns false if a student with that name already exists. */
    public boolean addStudent(String name) {
        GradeValidator.validateName(name);
        String trimmed = name.trim();
        if (studentsByName.containsKey(trimmed)) {
            return false;
        }
        Student student = new Student(nextId.getAndIncrement(), trimmed);
        studentsByName.put(trimmed, student);
        return true;
    }

    public void removeStudent(String name) throws StudentNotFoundException {
        if (!studentsByName.containsKey(name)) {
            throw new StudentNotFoundException(name);
        }
        studentsByName.remove(name);
    }

    public Student getStudent(String name) throws StudentNotFoundException {
        Student s = studentsByName.get(name);
        if (s == null) throw new StudentNotFoundException(name);
        return s;
    }

    public boolean exists(String name) {
        return studentsByName.containsKey(name);
    }

    public Collection<Student> getAllStudents() {
        return studentsByName.values();
    }

    public int studentCount() {
        return studentsByName.size();
    }

    public void clearAll() {
        studentsByName.clear();
        nextId.set(1);
    }
}
