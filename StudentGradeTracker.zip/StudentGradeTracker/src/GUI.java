import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * Main entry point and UI layer. Contains no business logic itself —
 * it only calls into StudentManager / GradeManager / ReportGenerator /
 * FileStorageManager and displays the results, catching their checked
 * exceptions and turning them into user-facing messages.
 */
public class GUI extends JFrame {

    private static final String FILE_NAME = "grades.csv";

    private final StudentManager studentManager = new StudentManager();
    private final GradeManager gradeManager = new GradeManager(studentManager);
    private final ReportGenerator reportGenerator = new ReportGenerator(studentManager);
    private final FileStorageManager fileStorageManager = new FileStorageManager();

    private DefaultTableModel tableModel;
    private JTextField nameField;
    private JComboBox<String> studentDropdown;
    private JComboBox<Subject> subjectDropdown;
    private JTextField gradeField;
    private JLabel summaryLabel;

    public GUI() {
        super("Student Grade Tracker");
        fileStorageManager.load(studentManager, gradeManager, FILE_NAME);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(750, 500);
        setLayout(new BorderLayout(10, 10));

        add(buildTopPanel(), BorderLayout.NORTH);
        add(buildTablePanel(), BorderLayout.CENTER);
        add(buildBottomPanel(), BorderLayout.SOUTH);

        refreshAll();

        addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                fileStorageManager.save(studentManager, FILE_NAME);
            }
        });
    }

    private JPanel buildTopPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        nameField = new JTextField(12);
        JButton addStudentBtn = new JButton("Add Student");
        addStudentBtn.addActionListener(e -> {
            try {
                if (studentManager.addStudent(nameField.getText())) {
                    nameField.setText("");
                    refreshAll();
                } else {
                    JOptionPane.showMessageDialog(this, "A student with that name already exists.");
                }
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        });

        JButton removeStudentBtn = new JButton("Remove Selected");
        removeStudentBtn.addActionListener(e -> {
            String selected = (String) studentDropdown.getSelectedItem();
            if (selected == null) return;
            try {
                studentManager.removeStudent(selected);
                refreshAll();
            } catch (StudentNotFoundException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        });

        panel.add(new JLabel("Student Name:"));
        panel.add(nameField);
        panel.add(addStudentBtn);
        panel.add(removeStudentBtn);
        return panel;
    }

    private JScrollPane buildTablePanel() {
        String[] columns = {"Name", "Mathematics", "English", "Science", "Average", "Letter Grade"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int col) {
                return false;
            }
        };
        JTable table = new JTable(tableModel);
        return new JScrollPane(table);
    }

    private JPanel buildBottomPanel() {
        JPanel wrapper = new JPanel(new BorderLayout());

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.LEFT));
        studentDropdown = new JComboBox<>();
        subjectDropdown = new JComboBox<>(Subject.values());
        gradeField = new JTextField(6);

        JButton setGradeBtn = new JButton("Set Grade");
        setGradeBtn.addActionListener(e -> {
            String student = (String) studentDropdown.getSelectedItem();
            Subject subject = (Subject) subjectDropdown.getSelectedItem();
            if (student == null || subject == null) return;
            try {
                double grade = Double.parseDouble(gradeField.getText().trim());
                gradeManager.setGrade(student, subject, grade);
                gradeField.setText("");
                refreshAll();
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Enter a valid number for the grade.");
            } catch (InvalidGradeException | StudentNotFoundException ex) {
                JOptionPane.showMessageDialog(this, ex.getMessage());
            }
        });

        JButton saveBtn = new JButton("Save");
        saveBtn.addActionListener(e -> {
            fileStorageManager.save(studentManager, FILE_NAME);
            JOptionPane.showMessageDialog(this, "Saved to " + FILE_NAME);
        });

        JButton reportBtn = new JButton("Full Report");
        reportBtn.addActionListener(e ->
            JOptionPane.showMessageDialog(this, reportGenerator.generateClassReport(),
                "Class Report", JOptionPane.INFORMATION_MESSAGE)
        );

        JButton resetBtn = new JButton("Reset All");
        resetBtn.addActionListener(e -> {
            int confirm = JOptionPane.showConfirmDialog(this,
                "This will delete all students and grades. Are you sure?",
                "Confirm Reset", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirm == JOptionPane.YES_OPTION) {
                studentManager.clearAll();
                fileStorageManager.save(studentManager, FILE_NAME);
                refreshAll();
                JOptionPane.showMessageDialog(this, "All data has been reset.");
            }
        });

        controls.add(new JLabel("Student:"));
        controls.add(studentDropdown);
        controls.add(new JLabel("Subject:"));
        controls.add(subjectDropdown);
        controls.add(new JLabel("Grade:"));
        controls.add(gradeField);
        controls.add(setGradeBtn);
        controls.add(saveBtn);
        controls.add(reportBtn);
        controls.add(resetBtn);

        summaryLabel = new JLabel(" ");
        summaryLabel.setBorder(BorderFactory.createEmptyBorder(4, 8, 8, 8));

        wrapper.add(controls, BorderLayout.NORTH);
        wrapper.add(summaryLabel, BorderLayout.SOUTH);
        return wrapper;
    }

    private void refreshAll() {
        tableModel.setRowCount(0);
        for (Student s : studentManager.getAllStudents()) {
            tableModel.addRow(new Object[]{
                s.getName(),
                s.getGrade(Subject.MATHEMATICS),
                s.getGrade(Subject.ENGLISH),
                s.getGrade(Subject.SCIENCE),
                String.format("%.2f", s.getAverage()),
                s.getLetterGrade()
            });
        }

        studentDropdown.removeAllItems();
        for (Student s : studentManager.getAllStudents()) {
            studentDropdown.addItem(s.getName());
        }

        Student top = reportGenerator.getTopPerformer();
        int atRiskCount = reportGenerator.getAtRiskStudents().size();
        summaryLabel.setText(String.format("Students: %d   Top performer: %s   At-risk: %d",
            studentManager.studentCount(),
            top == null ? "N/A" : top.getName(),
            atRiskCount));
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GUI().setVisible(true));
    }
}
