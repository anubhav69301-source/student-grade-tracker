/**
 * Fixed set of subjects tracked by the system.
 */
public enum Subject {
    MATHEMATICS("Mathematics"),
    ENGLISH("English"),
    SCIENCE("Science");

    private final String displayName;

    Subject(String displayName) {
        this.displayName = displayName;
    }

    public String getDisplayName() {
        return displayName;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
