import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Handles reading/writing the student roster to a CSV file.
 * Format: name,mathGrade,englishGrade,scienceGrade
 * Kept separate from StudentManager so storage format can change
 * without touching roster logic (maintainability NFR).
 */
public class FileStorageManager {

    public void save(StudentManager studentManager, String filename) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename))) {
            for (Student s : studentManager.getAllStudents()) {
                StringBuilder line = new StringBuilder(s.getName());
                for (Subject subject : Subject.values()) {
                    line.append(",").append(s.getGrade(subject));
                }
                writer.write(line.toString());
                writer.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error saving file: " + e.getMessage());
        }
    }

    public void load(StudentManager studentManager, GradeManager gradeManager, String filename) {
        File file = new File(filename);
        if (!file.exists()) return;

        studentManager.clearAll();
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            int lineNumber = 0;
            while ((line = reader.readLine()) != null) {
                lineNumber++;
                if (line.isBlank()) continue;
                String[] parts = line.split(",");
                String name = parts[0];
                studentManager.addStudent(name);

                Subject[] subjects = Subject.values();
                for (int i = 0; i < subjects.length && i + 1 < parts.length; i++) {
                    try {
                        double grade = Double.parseDouble(parts[i + 1]);
                        gradeManager.setGrade(name, subjects[i], grade);
                    } catch (NumberFormatException | InvalidGradeException | StudentNotFoundException e) {
                        System.err.println("Skipping bad value on line " + lineNumber + ": " + e.getMessage());
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading file: " + e.getMessage());
        }
    }
}
