import java.util.EnumMap;
import java.util.Map;

/**
 * Represents a single student and their grades across the fixed subject set.
 * This class is intentionally "dumb" — it stores data and computes simple
 * derived values (average, letter grade), but validation and orchestration
 * live in GradeValidator / StudentManager / GradeManager.
 */
public class Student {

    private final int id;
    private final String name;
    private final Map<Subject, Double> grades = new EnumMap<>(Subject.class);

    public Student(int id, String name) {
        this.id = id;
        this.name = name;
        for (Subject subject : Subject.values()) {
            grades.put(subject, 0.0);
        }
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public void setGrade(Subject subject, double value) {
        grades.put(subject, value);
    }

    public double getGrade(Subject subject) {
        return grades.getOrDefault(subject, 0.0);
    }

    public double getAverage() {
        double sum = 0;
        for (double g : grades.values()) sum += g;
        return sum / grades.size();
    }

    public String getLetterGrade() {
        double avg = getAverage();
        if (avg >= 90) return "A";
        if (avg >= 80) return "B";
        if (avg >= 70) return "C";
        if (avg >= 60) return "D";
        return "F";
    }

    @Override
    public String toString() {
        return String.format("[%d] %s - Avg: %.2f (%s)", id, name, getAverage(), getLetterGrade());
    }
}
