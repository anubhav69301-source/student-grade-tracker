/**
 * Thrown when an operation references a student that isn't in the roster.
 */
public class StudentNotFoundException extends Exception {
    public StudentNotFoundException(String studentName) {
        super("Student not found: " + studentName);
    }
}
