import java.util.Collection;
import java.util.ArrayList;
import java.util.List;

/**
 * MODULE 3: Reporting & Analytics
 * Reads from StudentManager (read-only) and computes class-wide statistics.
 * Kept separate from persistence and UI so the analytics logic can be
 * unit-tested in isolation.
 */
public class ReportGenerator {

    private final StudentManager studentManager;
    private double atRiskThreshold = 60.0;

    public ReportGenerator(StudentManager studentManager) {
        this.studentManager = studentManager;
    }

    public void setAtRiskThreshold(double threshold) {
        this.atRiskThreshold = threshold;
    }

    /** Class-wide average for a single subject, across all students. */
    public double getSubjectAverage(Subject subject) {
        Collection<Student> students = studentManager.getAllStudents();
        if (students.isEmpty()) return 0.0;
        double sum = 0;
        for (Student s : students) sum += s.getGrade(subject);
        return sum / students.size();
    }

    /** The student with the highest overall average. Returns null if roster is empty. */
    public Student getTopPerformer() {
        Student top = null;
        for (Student s : studentManager.getAllStudents()) {
            if (top == null || s.getAverage() > top.getAverage()) {
                top = s;
            }
        }
        return top;
    }

    /** Students whose average is below the at-risk threshold (default 60). */
    public List<Student> getAtRiskStudents() {
        List<Student> atRisk = new ArrayList<>();
        for (Student s : studentManager.getAllStudents()) {
            if (s.getAverage() < atRiskThreshold) {
                atRisk.add(s);
            }
        }
        return atRisk;
    }

    /** Full printable class report. */
    public String generateClassReport() {
        StringBuilder sb = new StringBuilder();
        sb.append("=== Class Report ===\n");
        for (Student s : studentManager.getAllStudents()) {
            sb.append(s).append("\n");
        }
        sb.append("\n--- Subject Averages ---\n");
        for (Subject subject : Subject.values()) {
            sb.append(String.format("%-12s %.2f%n", subject.getDisplayName(), getSubjectAverage(subject)));
        }
        Student top = getTopPerformer();
        sb.append("\nTop performer: ").append(top == null ? "N/A" : top.getName());
        sb.append("\nAt-risk students (avg < ").append(atRiskThreshold).append("): ");
        List<Student> atRisk = getAtRiskStudents();
        sb.append(atRisk.isEmpty() ? "None" : atRisk.size());
        return sb.toString();
    }
}
